# 25 Millennium Problem Proposals

**Project:** JSFEAT
**Upstream:** https://github.com/antimatter15/jsfeat

Content specific to JSFEAT in category ARTIST_TOOLS.
