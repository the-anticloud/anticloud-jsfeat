# 17 How To Update

**Project:** JSFEAT
**Upstream:** https://github.com/antimatter15/jsfeat

Content specific to JSFEAT in category ARTIST_TOOLS.
