# 08 Intellectual Property And Rights

**Project:** JSFEAT
**Upstream:** https://github.com/antimatter15/jsfeat

Content specific to JSFEAT in category ARTIST_TOOLS.
